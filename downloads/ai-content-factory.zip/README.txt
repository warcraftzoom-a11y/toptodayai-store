AI Content Factory - 5 n8n Workflow Templates
===============================================
VERSION: 1.0
INCLUDES: 5 n8n workflow templates

WORKFLOWS:
1. Auto Blog Generator (daily)
2. Social Media Scheduler (weekly)
3. SEO Article Factory
4. Email Newsletter Generator (weekly)
5. Telegram Daily Digest (daily)

SETUP:
1. Open n8n (n8n.io or self-hosted)
2. Import the JSON workflow
3. Add your API keys (DeepSeek, WordPress, Buffer, Telegram)
4. Set your schedule
5. Activate

REQUIREMENTS:
- n8n account (free tier works)
- DeepSeek API key (or any OpenAI-compatible API)
- Optional: WordPress, Buffer, Telegram Bot

LICENSE: Personal use. No redistribution.

ToptodayAI © 2026 - https://toptoday.pw
