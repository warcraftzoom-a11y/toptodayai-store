AI Social Media Manager - 53 Prompts Bundle
==========================================
VERSION: 1.0
INCLUDES: 53 ChatGPT prompts in 12 categories

HOW TO USE:
1. Open the JSON file
2. Copy any prompt
3. Paste into ChatGPT/Claude/DeepSeek
4. Replace [placeholders] with your niche/topic

CATEGORIES:
- Content Ideas Generator
- Hook & Headline Master
- Hashtag & SEO Strategy
- Engagement & Reply Scripts
- Analytics & Optimization
- Platform-Specific (Instagram, LinkedIn, Twitter/X)
- Video Content (TikTok/Reels/Shorts)
- Community Building & Growth
- Crisis Management & Brand Safety
- Bonus: AI Prompt Engineering Tips

LICENSE: Personal use. No redistribution.

ToptodayAI © 2026 - https://toptoday.pw
